import { and, asc, eq, isNull } from 'drizzle-orm';
import { db } from '../client';
import { newId } from '../id';
import { tasks } from '../schema';

export const tasksForDateQuery = (date: number) =>
  db.select().from(tasks)
    .where(and(eq(tasks.date, date), isNull(tasks.deletedAt)))
    .orderBy(asc(tasks.startMinute));

export async function addTask(input: {
  title: string; subjectId: string; date: number; startMinute: number; endMinute: number;
}) {
  await db.insert(tasks).values({ id: newId(), updatedAt: Date.now(), ...input });
}

export async function setTaskDone(id: string, done: boolean) {
  await db.update(tasks).set({ done, updatedAt: Date.now() }).where(eq(tasks.id, id));
}

export async function deleteTask(id: string) {
  const now = Date.now();
  await db.update(tasks).set({ deletedAt: now, updatedAt: now }).where(eq(tasks.id, id)); // soft delete
}