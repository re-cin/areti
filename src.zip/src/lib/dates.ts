export const startOfDay = (d: Date | number) => {
  const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime();
};
export const addDays = (ms: number, n: number) => {
  const x = new Date(ms); x.setDate(x.getDate() + n); return startOfDay(x);
};