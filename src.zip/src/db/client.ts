import { drizzle } from 'drizzle-orm/expo-sqlite';
import { openDatabaseSync } from 'expo-sqlite';
import * as schema from './schema';

const sqlite = openDatabaseSync('areti.db', { enableChangeListener: true });
export const db = drizzle(sqlite, { schema });
